package com.sismulador.analizadorsismos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnalizadorsismosApplicationTests {

	@Test
	void contextLoads() {
	}

}
