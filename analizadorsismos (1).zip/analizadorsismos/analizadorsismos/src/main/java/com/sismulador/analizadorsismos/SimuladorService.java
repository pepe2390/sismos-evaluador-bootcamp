/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sismulador.analizadorsismos;
/**
 * @author Luca
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;

@Service
public class SimuladorService {

    private final IGestionPoblacion gestorPoblacion;
    private final IBuscadorSismos buscadorSismos;
    private final Recomendador recomendador;
    private LocalDate fechaActualSimulacion;

    @Autowired // Inyección de dependencias automática
    public SimuladorService(IGestionPoblacion gestorPoblacion, IBuscadorSismos buscadorSismos) {
        this.gestorPoblacion = gestorPoblacion;
        this.buscadorSismos = buscadorSismos;
        // Instanciamos el recomendador pasando el gestor que Spring ya nos dio
        this.recomendador = new Recomendador(this.gestorPoblacion);
        this.fechaActualSimulacion = LocalDate.now();
    }

    public String simularPasoDeAnio() {
        this.fechaActualSimulacion = this.fechaActualSimulacion.plusYears(1);
        int year = this.fechaActualSimulacion.getYear();

        for (Provincia provincia : gestorPoblacion.getTodasLasProvincias()) {
            GestorDemografico.aplicarMortalidadNatural(provincia, fechaActualSimulacion);
        }
        return "Simulación completada. Nuevo año: " + year;
    }

    public String simularEvento(int indiceSismo) {
        var lista = buscadorSismos.getTodosLosSismos();
        
        if (lista.isEmpty()) return "Error: No hay sismos cargados.";
        if (indiceSismo < 0 || indiceSismo >= lista.size()) return "Error: Índice inválido.";

        Sismo sismo = lista.get(indiceSismo);
        
        // 1. Obtener texto de recomendación
        String reporteTexto = recomendador.generarRecomendacion(sismo);

        // 2. Aplicar impacto lógico a la base de datos en memoria
        Provincia provinciaAfectada = gestorPoblacion.buscarPorIndice(sismo.getProvinciaId());
        
        if (provinciaAfectada != null) {
            // Solo aplicamos si es grave o hay heridos, según tu lógica original
            if (sismo instanceof Terremoto || reporteTexto.contains("Heridos (Est.)")) {
                ReporteDestruccion datosImpacto = Destruccion.calcularImpacto(sismo, provinciaAfectada);
                GestorDemografico.aplicarMortalidadPorDesastre(provinciaAfectada, sismo, datosImpacto);
            }
        }

        return reporteTexto; // Esto es lo que verá WPF
    }
}
