/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sismulador.analizadorsismos;
/**
 * @author Luca
 */
import org.springframework.stereotype.Service;
import org.springframework.core.io.ClassPathResource;
import jakarta.annotation.PostConstruct;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BuscadorSismos implements IBuscadorSismos {

    private static final double LIMITE_TERREMOTO = 7.0;
    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ISO_LOCAL_DATE;
    private final String ARCHIVO_TXT = "datos.txt"; // Solo el nombre
    private List<Sismo> listaDeSismos;

    public BuscadorSismos() {
        this.listaDeSismos = new ArrayList<>();
    }

    @PostConstruct
    public void iniciarCarga() {
        cargarSismos(ARCHIVO_TXT);
    }

    @Override
    public void cargarSismos(String nombreArchivo) {
        try {
            var recurso = new ClassPathResource(nombreArchivo);
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(recurso.getInputStream()))) {
                
                reader.readLine(); // Omitir cabecera
                String linea;
                
                while ((linea = reader.readLine()) != null) {
                    String[] campos = linea.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
                    if (campos.length < 5) continue;

                    try {
                        LocalDate fecha = LocalDate.parse(campos[0].trim(), FORMATO_FECHA);
                        String region = campos[1].trim().replace("\"", "");
                        String provincia = campos[2].trim().replace("\"", "");
                        double magnitud = Double.parseDouble(campos[3].trim());
                        int provinciaId = Integer.parseInt(campos[4].trim());

                        Sismo nuevoSismo;
                        if (magnitud >= LIMITE_TERREMOTO) {
                            nuevoSismo = new Terremoto(magnitud, fecha, provincia, region, provinciaId);
                        } else {
                            nuevoSismo = new Temblor(magnitud, fecha, provincia, region, provinciaId);
                        }
                        this.listaDeSismos.add(nuevoSismo);

                    } catch (Exception e) {
                        System.err.println("Error sismo linea: " + linea);
                    }
                }
                System.out.println("Sismos cargados: " + listaDeSismos.size());
            }
        } catch (IOException e) {
            System.err.println("ERROR FATAL leyendo TXT sismos: " + e.getMessage());
        }
    }

    @Override
    public List<Sismo> buscarSismosPorProvincia(String nombreProvincia) {
        return this.listaDeSismos.stream()
                .filter(s -> s.getNombreProvinciaAfectada().equalsIgnoreCase(nombreProvincia.trim()))
                .collect(Collectors.toList());
    }

    @Override
    public List<Sismo> getTodosLosSismos() { return this.listaDeSismos; }
}