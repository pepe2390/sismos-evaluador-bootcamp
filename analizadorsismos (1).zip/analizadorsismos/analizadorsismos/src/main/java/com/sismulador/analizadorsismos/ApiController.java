/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sismulador.analizadorsismos;
/**
 * @author Luca
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.List;

@RestController
@RequestMapping("/api") // Prefijo para todas las rutas
public class ApiController {

    @Autowired
    private IBuscadorSismos buscadorSismos;

    @Autowired
    private IGestionPoblacion gestionPoblacion;

    @Autowired
    private SimuladorService simuladorService;

    // GET: http://localhost:8080/api/sismos
    @GetMapping("/sismos")
    public List<Sismo> obtenerSismos() {
        return buscadorSismos.getTodosLosSismos();
    }

    // GET: http://localhost:8080/api/provincias
    @GetMapping("/provincias")
    public Collection<Provincia> obtenerProvincias() {
        return gestionPoblacion.getTodasLasProvincias();
    }

    // GET: http://localhost:8080/api/provincias/37
    @GetMapping("/provincias/{id}")
    public Provincia obtenerProvinciaPorId(@PathVariable int id) {
        return gestionPoblacion.buscarPorIndice(id);
    }

    // POST: http://localhost:8080/api/simular/anio
    @PostMapping("/simular/anio")
    public String simularAnio() {
        return simuladorService.simularPasoDeAnio();
    }

    // POST: http://localhost:8080/api/simular/sismo?indice=0
    @PostMapping("/simular/sismo")
    public String simularSismo(@RequestParam int indice) {
        return simuladorService.simularEvento(indice);
    }
}