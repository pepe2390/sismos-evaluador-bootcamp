/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sismulador.analizadorsismos;

/**
 * @author Luca
 */
import org.springframework.stereotype.Service;
import org.springframework.core.io.ClassPathResource;
import jakarta.annotation.PostConstruct; // Usa 'javax.annotation' si usas Java antiguo

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

@Service
public class GestionPoblacion implements IGestionPoblacion {

    private Map<Integer, Provincia> mapaProvincias;
    private final String ARCHIVO_CSV = "poblaciones_con_indice.csv"; // Solo el nombre

    public GestionPoblacion() {
        this.mapaProvincias = new HashMap<>();
    }

    @PostConstruct // Se ejecuta automáticamente al iniciar la App
    public void iniciarCarga() {
        importarCSV(ARCHIVO_CSV);
    }

    @Override
    public void importarCSV(String nombreArchivo) {
        try {
            // CAMBIO CLAVE: Usamos ClassPathResource para leer dentro del proyecto
            var recurso = new ClassPathResource(nombreArchivo);
            
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(recurso.getInputStream()))) {
                reader.readLine(); // Omitir cabecera
                String linea;

                while ((linea = reader.readLine()) != null) {
                    // Tu lógica de siempre
                    String[] campos = linea.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
                    if (campos.length < 12) continue;

                    try {
                        String indiceStr = campos[0].trim().replace("\"", "");
                        String numRegion = campos[1].trim().replace("\"", "");
                        String nomRegion = campos[2].trim().replace("\"", "");
                        String nomProv = campos[3].trim().replace("\"", "");
                        String poblacionStr = campos[4].trim().replace("\"", "");
                        String superficieKm2Str = campos[5].trim().replace("\"", "");
                        String tipoSuperficie = campos[6].trim().replace("\"", "");
                        
                        // Recursos
                        int luz = Integer.parseInt(campos[7].trim().replace("\"", ""));
                        int agua = Integer.parseInt(campos[8].trim().replace("\"", ""));
                        int comida = Integer.parseInt(campos[9].trim().replace("\"", ""));
                        int medicamentos = Integer.parseInt(campos[10].trim().replace("\"", ""));
                        int comunicaciones = Integer.parseInt(campos[11].trim().replace("\"", ""));

                        int indice = Integer.parseInt(indiceStr);
                        long poblacion = Long.parseLong(poblacionStr);
                        int superficieKm2 = Integer.parseInt(superficieKm2Str);

                        Recursos recursos = new Recursos(luz, agua, comida, medicamentos, comunicaciones);
                        
                        Provincia provincia = new Provincia(indice, nomProv, poblacion, superficieKm2, tipoSuperficie,
                                numRegion, nomRegion, recursos);

                        this.mapaProvincias.put(indice, provincia);

                    } catch (NumberFormatException e) {
                        System.err.println("Error parseando línea: " + e.getMessage());
                    }
                }
                System.out.println("Provincias cargadas: " + mapaProvincias.size());
            }
        } catch (IOException e) {
            System.err.println("ERROR FATAL leyendo CSV: " + e.getMessage());
        }
    }

    @Override
    public Provincia buscarPorIndice(int indice) { return this.mapaProvincias.get(indice); }

    @Override
    public Provincia buscarPorNombre(String nombre) {
        return this.mapaProvincias.values().stream()
                .filter(p -> p.getNombreProvincia().equalsIgnoreCase(nombre.trim()))
                .findFirst().orElse(null);
    }

    @Override
    public Collection<Provincia> getTodasLasProvincias() { return this.mapaProvincias.values(); }

    @Override
    public boolean modificarPoblacion(int indice, long nuevaPoblacion) {
        Provincia p = buscarPorIndice(indice);
        if (p != null) {
            p.setPoblacion(nuevaPoblacion);
            return true;
        }
        return false;
    }
}