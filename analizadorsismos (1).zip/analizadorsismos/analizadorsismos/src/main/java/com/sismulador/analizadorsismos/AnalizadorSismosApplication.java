/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.sismulador.analizadorsismos;
/**
 * @author Luca
 */
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnalizadorSismosApplication {

    public static void main(String[] args) {
        // Arranca la aplicación y el servidor Tomcat en el puerto 8080
        SpringApplication.run(AnalizadorSismosApplication.class, args);
    }
}